import axios from "axios";

export const selectProject = (project) => {
  console.log("Clicked", project)
  return {
    type: "PROJECT_SELECTED",
    payload: project
  }
}

export function fetchProjects() {
  return (dispatch) => {
      axios.get("http://localhost:8080/api/projects")
      .then((response) => {
        dispatch({ type: "FETCH_PROJECTS_FULFILLED", payload: response.data.projects_data })
        //console.log(response.data.projects_data)
      })
      .catch((err) => {
        dispatch({ type: "FETCH_PROJECTS_REJECTED", payload: err })
        //console.log(err)
      })
  }
}
