import React, { Component} from 'react';
import { PropTypes } from 'prop-types';
import { connect } from "react-redux"
import {Link, Route} from "react-router-dom"
import ReactDOM from "react-dom"

export default class Navbar extends Component {
    render() {
        return (
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li class=""><Link to="/"> Home </Link></li>
                                <li class=""><Link to="/about"> About </Link></li>
                                <li class=""><Link to="/projects"> Project </Link></li>
                                <li class=""><Link to="/project/new"> Add New Work </Link></li>
                                <li class=""><Link to="/contact"> Contact </Link></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        )
    }
}


