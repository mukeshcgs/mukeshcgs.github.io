import React, { Component} from 'react';


export default class ContactPage extends Component {
    render() {
        return (
            <div><h1>Conatct Page</h1></div>
        )
    }
}


