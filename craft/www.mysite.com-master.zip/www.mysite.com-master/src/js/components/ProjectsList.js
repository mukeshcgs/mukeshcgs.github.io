import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { selectProject } from '../actions/projectsActions'

class ProjectsList extends Component {
    createListItems() {
		console.log(this.props.projects);
        if (!this.props.projects.projects.length > 0) {
            return <div class="text-danger"> No projects found</div>
        }
        return (this.props.projects.projects.map(project =>
            <li key={project._id} onClick={() => this.props.selectProject(project)} >
                {project.name}
            </li>)
        )
    }
    render() {
        return (<ul>{this.createListItems()}</ul>)
    }
}
function mapStateToProps(state) {
    return {
        projects: state.projects
    }
}
 function mapDispatchToProps(dispatch) {
    return bindActionCreators({ selectProject }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(ProjectsList);