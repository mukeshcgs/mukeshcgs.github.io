import React, { Component} from 'react';
import { PropTypes } from 'prop-types';
import { connect } from "react-redux"
import {Link} from "react-router-dom"

import ProjectsList from "./ProjectsList";
import {fetchProjects} from "../actions/projectsActions";
import { selectProject } from '../actions/projectsActions'


class ProjectsPage extends Component {
    
    componantDidMount(){
        this.props.fetchProjects();
    }
    render() {
        return (
            <div>
                <h1>Project Page</h1>
                <ProjectsList projects={this.props.projects} />
            </div>
        )
    }
};

 ProjectsPage.PropTypes = {
 	projects: React.PropTypes.array.isRequired,
    fetchProjects: React.PropTypes.func.isRequired,
	selectProject: React.PropTypes.func.isRequired
 };

 function mapStateToProps(state){
	return{
		projects:state.projects
	}
}

export default connect(mapStateToProps, fetchProjects)(ProjectsPage);
