/* jshint esnext: true */
// import Ractive from '../ractive/ractive';
// import svg4everybody from 'svg4everybody';
import PageTransitionsManager from '../modules/PageTransitionsManager';

export default function () {
	// window.Ractive.DEBUG = false;
	// svg4everybody();
	var pagetransitionsManager = new PageTransitionsManager();
}