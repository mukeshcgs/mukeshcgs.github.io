import AbstractModule from "./AbstractModule";
// ==========================================================================
// Generic module
// ==========================================================================
export default class extends AbstractModule {
    constructor(options) {
        super(options);
    }
};