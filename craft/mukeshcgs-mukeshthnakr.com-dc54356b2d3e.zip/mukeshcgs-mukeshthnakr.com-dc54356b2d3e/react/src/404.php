<?php
   header('Location: styles.css');
   exit;
?>